<?php
App::uses('AppController', 'Controller');

class TinymceElfinderAppController extends AppController {
	
}
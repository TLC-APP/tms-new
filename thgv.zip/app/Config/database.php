<?php

class DATABASE_CONFIG {

    public $default = array(
        
        'datasource' => 'Database/Mysql',
        'persistent' => false,
        'host' => 'localhost',
        'login' => 'root',
        'password' => '',
        'database' => 'thgv_test',
        'prefix' => '',
        'encoding' => 'utf8'

    );
    public $default1 = array(
        
        'datasource' => 'Database/Mysql',
        'persistent' => false,
        'host' => 'localhost',
        'login' => 'tlc',
        'password' => 'ta8agusa4',
        'database' => 'tlc_thgv',
        'prefix' => '',
        'encoding' => 'utf8'

    );
    public $test = array(
        
        'datasource' => 'Database/Mysql',
        'persistent' => false,
        'host' => 'localhost',
        'login' => 'root',
        'password' => '',
        'database' => 'thgv_test',
        'prefix' => '',
        'encoding' => 'utf8'
    );
    
}
